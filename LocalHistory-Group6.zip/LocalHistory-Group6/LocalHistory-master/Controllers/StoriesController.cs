﻿using Microsoft.AspNetCore.Mvc;
using LocalHistory.Models;
using System.Linq;
using LocalHistory.Data;
using Microsoft.EntityFrameworkCore.Migrations;

public class StoriesController : Controller
{
    private readonly ApplicationDbContext _context;

    public StoriesController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: Stories/Create
    

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Story story)
    {
        if (ModelState.IsValid)
        {
            _context.Stories.Add(story);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
        return View(story);
    }


    public IActionResult Index(string search)
    {
        // Retrieve all stories from the database
        IQueryable<Story> stories = _context.Stories;

        // Filter stories based on the search query
        if (!string.IsNullOrEmpty(search))
        {
            stories = stories.Where(s => s.Title.Contains(search));
        }

        // Pass the filtered stories to the view
        return View(stories.ToList());
    }

    public IActionResult Create()
    {
        return View();
    }
}
